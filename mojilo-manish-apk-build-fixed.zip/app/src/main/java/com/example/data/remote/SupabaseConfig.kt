package com.example.data.remote

import android.content.Context
import android.content.SharedPreferences

object SupabaseConfig {
    private const val PREFS_NAME = "supabase_config_prefs"
    private const val KEY_SUPABASE_URL = "supabase_url"
    private const val KEY_SUPABASE_KEY = "supabase_anon_key"

    const val DEFAULT_URL = "https://ftwfajtmjmturviulrky.supabase.co"
    const val DEFAULT_ANON_KEY = "sb_publishable_6DU18ep-ZR7bChnte4NS7g_rHdi1nMm"

    fun getSupabaseUrl(context: Context): String {
        val savedUrl = getPrefs(context).getString(KEY_SUPABASE_URL, null)
        return if (!savedUrl.isNullOrBlank()) savedUrl!! else DEFAULT_URL
    }

    fun getSupabaseAnonKey(context: Context): String {
        val savedKey = getPrefs(context).getString(KEY_SUPABASE_KEY, null)
        return if (!savedKey.isNullOrBlank()) savedKey!! else DEFAULT_ANON_KEY
    }

    fun saveConfig(context: Context, url: String, anonKey: String) {
        getPrefs(context).edit()
            .putString(KEY_SUPABASE_URL, url.trim())
            .putString(KEY_SUPABASE_KEY, anonKey.trim())
            .apply()
    }

    private fun getPrefs(context: Context): SharedPreferences {
        return context.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE)
    }
}
