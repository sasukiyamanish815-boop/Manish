package com.example.ui.theme

import androidx.compose.ui.graphics.Color

// Elegant Dark Theme Palette
val DarkBackground = Color(0xFF1C1B1F)
val DarkSurface = Color(0xFF2B2930)
val DarkSurfaceVariant = Color(0xFF36343B)
val DarkOutline = Color(0xFF49454F)

// Primary Accent & Headers
val PurplePrimary = Color(0xFFD0BCFF)
val PurpleOnPrimary = Color(0xFF381E72)
val PurpleHeaderDark = Color(0xFF381E72)
val PurpleHeaderLight = Color(0xFF49454F)

// Header color used by the admin dashboard
val PurpleHeader = PurpleHeaderDark

// Text Colors
val TextOnDarkPrimary = Color(0xFFE6E1E5)
val TextOnDarkSecondary = Color(0xFFCAC4D0)
val TextOnDarkMuted = Color(0xFF938F99)

// Status & Badges
val EmeraldSuccess = Color(0xFF4CAF50)
val EmeraldOnContainer = Color(0xFF0B3D12)
val EmeraldContainer = Color(0xFFB7F0BE)

val AmberWarning = Color(0xFFFFB74D)
val AmberOnContainer = Color(0xFF4A2500)
val AmberContainer = Color(0xFFFFC66D)

val RoseError = Color(0xFFF2B8B5)
val RoseOnContainer = Color(0xFF601410)
val RoseContainer = Color(0xFF3B0907)

// Aliases for layout component compatibility
val IndigoPrimary = PurplePrimary
val IndigoDark = PurpleHeaderDark
val BlueSecondary = Color(0xFFA8C7FA)

val SlateBackground = DarkBackground
val SlateSurface = DarkSurface
val SlateOutline = DarkOutline

val TextPrimary = TextOnDarkPrimary
val TextSecondary = TextOnDarkSecondary
val TextMuted = TextOnDarkMuted

