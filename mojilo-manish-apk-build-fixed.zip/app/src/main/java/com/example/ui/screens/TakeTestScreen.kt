package com.example.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.automirrored.filled.ArrowForward
import androidx.compose.material.icons.filled.Check
import androidx.compose.material.icons.filled.Send
import androidx.compose.material.icons.filled.Timer
import androidx.compose.material3.*
import androidx.compose.runtime.*
import kotlinx.coroutines.delay
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.models.QuestionItem
import com.example.data.models.TestItem
import com.example.ui.theme.*

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun TakeTestScreen(
    test: TestItem,
    questions: List<QuestionItem>,
    currentQuestionIndex: Int,
    selectedAnswers: Map<String, Int>,
    onSelectOption: (questionId: String, optionIndex: Int) -> Unit,
    onGoToQuestion: (Int) -> Unit,
    onSubmitTest: () -> Unit,
    onBack: () -> Unit
) {
    var showSubmitConfirmDialog by remember { mutableStateOf(false) }
    var remainingSeconds by remember(test.id) { mutableIntStateOf(30 * 60) }
    var autoSubmitted by remember(test.id) { mutableStateOf(false) }

    // The current Supabase TestItem has no duration field, so the test timer is
    // intentionally kept local at 30 minutes. No timer data is saved to Supabase.
    LaunchedEffect(test.id) {
        while (remainingSeconds > 0 && !autoSubmitted) {
            delay(1000L)
            remainingSeconds -= 1
        }
        if (remainingSeconds == 0 && !autoSubmitted) {
            autoSubmitted = true
            onSubmitTest()
        }
    }

    val timerMinutes = remainingSeconds / 60
    val timerSeconds = remainingSeconds % 60
    val timerText = String.format("%02d:%02d", timerMinutes, timerSeconds)
    val timerUrgent = remainingSeconds <= 5 * 60

    if (questions.isEmpty()) {
        Box(
            modifier = Modifier
                .fillMaxSize()
                .padding(24.dp),
            contentAlignment = Alignment.Center
        ) {
            Text("પ્રશ્નો લોડ થઈ રહ્યા છે...")
        }
        return
    }

    val currentQuestion = questions[currentQuestionIndex]
    val selectedOptionIndex = selectedAnswers[currentQuestion.id]

    if (showSubmitConfirmDialog) {
        val answeredCount = selectedAnswers.size
        val totalCount = questions.size

        AlertDialog(
            onDismissRequest = { showSubmitConfirmDialog = false },
            title = { Text("પરીક્ષા સબમિટ કરો (Submit Test)", fontWeight = FontWeight.Bold) },
            text = {
                Text(
                    "તમે $totalCount માંથી $answeredCount પ્રશ્નોના ઉત્તર આપ્યા છે.\n\nશું તમે ખરેખર પરીક્ષા સબમિટ કરવા માંગો છો?"
                )
            },
            confirmButton = {
                Button(
                    onClick = {
                        showSubmitConfirmDialog = false
                        onSubmitTest()
                    },
                    colors = ButtonDefaults.buttonColors(containerColor = EmeraldSuccess),
                    modifier = Modifier.testTag("confirm_submit_button")
                ) {
                    Text("હા, સબમિટ કરો (Submit)", color = Color.White)
                }
            },
            dismissButton = {
                TextButton(onClick = { showSubmitConfirmDialog = false }) {
                    Text("રદ કરો (Cancel)")
                }
            }
        )
    }

    Scaffold(
        topBar = {
            TopAppBar(
                title = {
                    Column {
                        Text(
                            text = test.title,
                            style = MaterialTheme.typography.titleMedium.copy(
                                fontWeight = FontWeight.Bold,
                                color = Color.White
                            ),
                            maxLines = 1
                        )
                        Text(
                            text = "પ્રશ્ન ${currentQuestionIndex + 1} / ${questions.size}",
                            style = MaterialTheme.typography.bodySmall.copy(color = Color.White.copy(alpha = 0.8f))
                        )
                    }
                },
                navigationIcon = {
                    IconButton(onClick = onBack) {
                        Icon(Icons.AutoMirrored.Filled.ArrowBack, contentDescription = "Back", tint = Color.White)
                    }
                },
                actions = {
                    Surface(
                        shape = RoundedCornerShape(10.dp),
                        color = if (timerUrgent) MaterialTheme.colorScheme.error.copy(alpha = 0.95f) else Color.White.copy(alpha = 0.16f)
                    ) {
                        Row(
                            modifier = Modifier.padding(horizontal = 8.dp, vertical = 6.dp),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Icon(
                                Icons.Default.Timer,
                                contentDescription = "બાકી સમય",
                                tint = Color.White,
                                modifier = Modifier.size(16.dp)
                            )
                            Spacer(modifier = Modifier.width(4.dp))
                            Text(
                                text = timerText,
                                color = Color.White,
                                fontWeight = FontWeight.Bold,
                                fontSize = 13.sp
                            )
                        }
                    }
                    Spacer(modifier = Modifier.width(4.dp))
                    Button(
                        onClick = { showSubmitConfirmDialog = true },
                        colors = ButtonDefaults.buttonColors(containerColor = EmeraldSuccess),
                        contentPadding = PaddingValues(horizontal = 12.dp, vertical = 6.dp),
                        modifier = Modifier
                            .padding(end = 8.dp)
                            .testTag("submit_test_button")
                    ) {
                        Icon(Icons.Default.Send, contentDescription = null, modifier = Modifier.size(16.dp))
                        Spacer(modifier = Modifier.width(4.dp))
                        Text("સબમિટ (Submit)", fontSize = 13.sp)
                    }
                },
                colors = TopAppBarDefaults.topAppBarColors(containerColor = IndigoPrimary),
                windowInsets = WindowInsets.safeDrawing.only(WindowInsetsSides.Horizontal + WindowInsetsSides.Top)
            )
        }
    ) { innerPadding ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(innerPadding)
                .background(MaterialTheme.colorScheme.background)
        ) {
            // Linear Progress Bar
            LinearProgressIndicator(
                progress = { (currentQuestionIndex + 1).toFloat() / questions.size.toFloat() },
                modifier = Modifier.fillMaxWidth(),
                color = EmeraldSuccess,
                trackColor = IndigoDark.copy(alpha = 0.2f)
            )

            // Clean, compact progress summary.
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 16.dp, vertical = 10.dp),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text(
                    text = "પ્રશ્ન ${currentQuestionIndex + 1} / ${questions.size}",
                    fontWeight = FontWeight.Bold,
                    color = TextPrimary
                )
                Text(
                    text = "જવાબ આપ્યા: ${selectedAnswers.size} / ${questions.size}",
                    color = TextSecondary,
                    fontSize = 13.sp
                )
            }

            Column(
                modifier = Modifier
                    .weight(1f)
                    .padding(16.dp)
                    .verticalScroll(rememberScrollState())
            ) {
                // Question Card
                Card(
                    modifier = Modifier.fillMaxWidth(),
                    shape = RoundedCornerShape(16.dp),
                    colors = CardDefaults.cardColors(containerColor = SlateSurface),
                    elevation = CardDefaults.cardElevation(defaultElevation = 2.dp)
                ) {
                    Column(modifier = Modifier.padding(20.dp)) {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Surface(
                                shape = RoundedCornerShape(8.dp),
                                color = MaterialTheme.colorScheme.primaryContainer
                            ) {
                                Text(
                                    text = "પ્રશ્ન ${currentQuestionIndex + 1}",
                                    modifier = Modifier.padding(horizontal = 10.dp, vertical = 4.dp),
                                    style = MaterialTheme.typography.labelMedium.copy(
                                        fontWeight = FontWeight.Bold,
                                        color = MaterialTheme.colorScheme.onPrimaryContainer
                                    )
                                )
                            }

                            Text(
                                text = "ગુણ: ${currentQuestion.marks}",
                                style = MaterialTheme.typography.labelLarge.copy(
                                    fontWeight = FontWeight.Bold,
                                    color = IndigoPrimary
                                )
                            )
                        }

                        Spacer(modifier = Modifier.height(16.dp))

                        Text(
                            text = currentQuestion.questionText,
                            style = MaterialTheme.typography.titleMedium.copy(
                                fontWeight = FontWeight.SemiBold,
                                fontSize = 18.sp,
                                color = TextPrimary,
                                lineHeight = 26.sp
                            )
                        )
                    }
                }

                Spacer(modifier = Modifier.height(20.dp))

                Text(
                    text = "સાચો વિકલ્પ પસંદ કરો:",
                    style = MaterialTheme.typography.labelLarge.copy(
                        color = TextSecondary,
                        fontWeight = FontWeight.Bold
                    )
                )

                Spacer(modifier = Modifier.height(10.dp))

                // Options List
                // As soon as the student selects an answer, the correct answer is revealed.
                currentQuestion.options.forEachIndexed { index, optionText ->
                    val isSelected = selectedOptionIndex == index
                    val isCorrect = currentQuestion.correctOptionIndex == index
                    val hasAnswered = selectedOptionIndex != null
                    val isWrongSelected = hasAnswered && isSelected && !isCorrect
                    val optionLabel = when (index) {
                        0 -> "(A)"
                        1 -> "(B)"
                        2 -> "(C)"
                        3 -> "(D)"
                        else -> "(${index + 1})"
                    }

                    val borderColor = when {
                        hasAnswered && isCorrect -> EmeraldSuccess
                        isWrongSelected -> MaterialTheme.colorScheme.error
                        isSelected -> IndigoPrimary
                        else -> SlateOutline
                    }

                    val backgroundColor = when {
                        hasAnswered && isCorrect -> EmeraldSuccess.copy(alpha = 0.16f)
                        isWrongSelected -> MaterialTheme.colorScheme.errorContainer
                        isSelected -> MaterialTheme.colorScheme.primaryContainer
                        else -> SlateSurface
                    }

                    Card(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(vertical = 6.dp)
                            .clip(RoundedCornerShape(12.dp))
                            .border(
                                width = if (hasAnswered && (isCorrect || isSelected)) 2.dp else 1.dp,
                                color = borderColor,
                                shape = RoundedCornerShape(12.dp)
                            )
                            .clickable { onSelectOption(currentQuestion.id, index) },
                        shape = RoundedCornerShape(12.dp),
                        colors = CardDefaults.cardColors(containerColor = backgroundColor)
                    ) {
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(16.dp),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            RadioButton(
                                selected = isSelected,
                                onClick = { onSelectOption(currentQuestion.id, index) },
                                colors = RadioButtonDefaults.colors(
                                    selectedColor = when {
                                        isWrongSelected -> MaterialTheme.colorScheme.error
                                        isCorrect && hasAnswered -> EmeraldSuccess
                                        else -> IndigoPrimary
                                    }
                                )
                            )

                            Spacer(modifier = Modifier.width(8.dp))

                            Text(
                                text = "$optionLabel $optionText",
                                style = MaterialTheme.typography.bodyLarge.copy(
                                    fontWeight = if (isSelected || (hasAnswered && isCorrect)) FontWeight.Bold else FontWeight.Normal,
                                    color = when {
                                        hasAnswered && isCorrect -> EmeraldSuccess
                                        isWrongSelected -> MaterialTheme.colorScheme.error
                                        isSelected -> MaterialTheme.colorScheme.primary
                                        else -> TextPrimary
                                    }
                                ),
                                modifier = Modifier.weight(1f)
                            )

                            if (hasAnswered && isCorrect) {
                                Icon(
                                    imageVector = Icons.Default.Check,
                                    contentDescription = "સાચો જવાબ",
                                    tint = EmeraldSuccess,
                                    modifier = Modifier.size(22.dp)
                                )
                            } else if (isWrongSelected) {
                                Text(
                                    text = "✕",
                                    color = MaterialTheme.colorScheme.error,
                                    fontWeight = FontWeight.Bold,
                                    fontSize = 22.sp
                                )
                            }
                        }
                    }
                }

                // Immediate answer feedback
                if (selectedOptionIndex != null) {
                    val correctIndex = currentQuestion.correctOptionIndex
                    val correctLabel = when (correctIndex) {
                        0 -> "(A)"
                        1 -> "(B)"
                        2 -> "(C)"
                        3 -> "(D)"
                        else -> "(${correctIndex + 1})"
                    }
                    val answeredCorrectly = selectedOptionIndex == correctIndex

                    Card(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(top = 12.dp),
                        shape = RoundedCornerShape(12.dp),
                        colors = CardDefaults.cardColors(
                            containerColor = if (answeredCorrectly)
                                EmeraldSuccess.copy(alpha = 0.16f)
                            else
                                MaterialTheme.colorScheme.errorContainer
                        )
                    ) {
                        Column(modifier = Modifier.padding(16.dp)) {
                            Text(
                                text = if (answeredCorrectly) "✓ સાચો જવાબ!" else "✕ જવાબ ખોટો છે",
                                fontWeight = FontWeight.Bold,
                                fontSize = 17.sp,
                                color = if (answeredCorrectly) EmeraldSuccess else MaterialTheme.colorScheme.error
                            )
                            Spacer(modifier = Modifier.height(6.dp))
                            Text(
                                text = "સાચો જવાબ: $correctLabel ${currentQuestion.options[correctIndex]}",
                                fontWeight = FontWeight.Bold,
                                color = TextPrimary
                            )
                        }
                    }
                }
            }

            // Clear Previous / Next navigation.
            Card(
                modifier = Modifier.fillMaxWidth(),
                shape = RoundedCornerShape(topStart = 18.dp, topEnd = 18.dp),
                colors = CardDefaults.cardColors(containerColor = SlateSurface),
                elevation = CardDefaults.cardElevation(defaultElevation = 8.dp)
            ) {
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(horizontal = 14.dp, vertical = 12.dp),
                    horizontalArrangement = Arrangement.spacedBy(10.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    OutlinedButton(
                        onClick = { onGoToQuestion(currentQuestionIndex - 1) },
                        enabled = currentQuestionIndex > 0,
                        modifier = Modifier.weight(1f),
                        shape = RoundedCornerShape(12.dp),
                        contentPadding = PaddingValues(horizontal = 8.dp, vertical = 10.dp)
                    ) {
                        Icon(Icons.AutoMirrored.Filled.ArrowBack, contentDescription = null, modifier = Modifier.size(18.dp))
                        Spacer(modifier = Modifier.width(5.dp))
                        Text("પાછળ", fontWeight = FontWeight.Bold)
                    }

                    Surface(
                        shape = RoundedCornerShape(10.dp),
                        color = MaterialTheme.colorScheme.primaryContainer
                    ) {
                        Text(
                            text = "${currentQuestionIndex + 1}/${questions.size}",
                            modifier = Modifier.padding(horizontal = 10.dp, vertical = 9.dp),
                            fontWeight = FontWeight.Bold,
                            color = MaterialTheme.colorScheme.onPrimaryContainer
                        )
                    }

                    Button(
                        onClick = {
                            if (currentQuestionIndex < questions.size - 1) {
                                onGoToQuestion(currentQuestionIndex + 1)
                            } else {
                                showSubmitConfirmDialog = true
                            }
                        },
                        modifier = Modifier.weight(1f),
                        shape = RoundedCornerShape(12.dp),
                        contentPadding = PaddingValues(horizontal = 8.dp, vertical = 10.dp),
                        colors = ButtonDefaults.buttonColors(
                            containerColor = if (currentQuestionIndex == questions.size - 1) EmeraldSuccess else IndigoPrimary
                        )
                    ) {
                        Text(
                            if (currentQuestionIndex == questions.size - 1) "સબમિટ" else "આગળ",
                            fontWeight = FontWeight.Bold
                        )
                        Spacer(modifier = Modifier.width(5.dp))
                        Icon(Icons.AutoMirrored.Filled.ArrowForward, contentDescription = null, modifier = Modifier.size(18.dp))
                    }
                }
            }
        }
    }
}
