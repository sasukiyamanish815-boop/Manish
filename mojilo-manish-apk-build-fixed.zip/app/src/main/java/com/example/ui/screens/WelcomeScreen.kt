package com.example.ui.screens

import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.core.FastOutSlowInEasing
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.tween
import androidx.compose.animation.fadeIn
import androidx.compose.animation.scaleIn
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.School
import androidx.compose.material.icons.filled.WavingHand
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.scale
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.ui.theme.IndigoDark
import com.example.ui.theme.IndigoPrimary
import kotlinx.coroutines.delay

@Composable
fun WelcomeScreen(
    name: String,
    onFinished: () -> Unit
) {
    var visible by remember { mutableStateOf(false) }
    var progress by remember { mutableStateOf(0f) }
    var buttonVisible by remember { mutableStateOf(false) }

    val iconScale by animateFloatAsState(
        targetValue = if (visible) 1f else 0.55f,
        animationSpec = tween(700, easing = FastOutSlowInEasing),
        label = "welcomeIconScale"
    )

    LaunchedEffect(Unit) {
        visible = true
        for (i in 1..20) {
            delay(100)
            progress = i / 20f
        }
        buttonVisible = true
        delay(900)
        onFinished()
    }

    Box(
        modifier = Modifier
            .fillMaxSize()
            .background(
                Brush.verticalGradient(listOf(IndigoPrimary, IndigoDark))
            )
            .padding(24.dp),
        contentAlignment = Alignment.Center
    ) {
        Column(
            horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.Center,
            modifier = Modifier.fillMaxWidth()
        ) {
            AnimatedVisibility(
                visible = visible,
                enter = fadeIn(tween(600)) + scaleIn(tween(700))
            ) {
                Box(
                    modifier = Modifier
                        .size(112.dp)
                        .scale(iconScale)
                        .background(Color.White.copy(alpha = 0.13f), CircleShape),
                    contentAlignment = Alignment.Center
                ) {
                    Icon(
                        imageVector = Icons.Filled.WavingHand,
                        contentDescription = null,
                        tint = Color(0xFFFFD166),
                        modifier = Modifier.size(62.dp)
                    )
                }
            }

            Spacer(modifier = Modifier.height(30.dp))

            Text(
                text = "Welcome!",
                color = Color.White,
                fontSize = 32.sp,
                fontWeight = FontWeight.Bold
            )

            Spacer(modifier = Modifier.height(8.dp))

            Text(
                text = name,
                color = Color.White.copy(alpha = 0.95f),
                fontSize = 24.sp,
                fontWeight = FontWeight.SemiBold,
                textAlign = TextAlign.Center
            )

            Spacer(modifier = Modifier.height(18.dp))

            Row(verticalAlignment = Alignment.CenterVertically) {
                Icon(Icons.Filled.CheckCircle, contentDescription = null, tint = Color(0xFF8EF0A8))
                Spacer(modifier = Modifier.width(8.dp))
                Text(
                    text = "Login સફળ થયું છે",
                    color = Color.White.copy(alpha = 0.9f),
                    fontSize = 17.sp
                )
            }

            Spacer(modifier = Modifier.height(12.dp))

            Text(
                text = "તમારી મહેનત સફળતામાં બદલાય.\nચાલો, આજે કંઈક નવું શીખીએ! 🚀",
                color = Color.White.copy(alpha = 0.82f),
                fontSize = 16.sp,
                lineHeight = 25.sp,
                textAlign = TextAlign.Center
            )

            Spacer(modifier = Modifier.height(30.dp))

            LinearProgressIndicator(
                progress = { progress },
                modifier = Modifier
                    .fillMaxWidth(0.72f)
                    .height(5.dp),
                color = Color.White,
                trackColor = Color.White.copy(alpha = 0.18f)
            )

            Spacer(modifier = Modifier.height(22.dp))

            AnimatedVisibility(visible = buttonVisible, enter = fadeIn(tween(400))) {
                Surface(
                    shape = RoundedCornerShape(18.dp),
                    color = Color.White.copy(alpha = 0.12f)
                ) {
                    Row(
                        modifier = Modifier.padding(horizontal = 22.dp, vertical = 12.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Icon(Icons.Filled.School, contentDescription = null, tint = Color.White)
                        Spacer(modifier = Modifier.width(8.dp))
                        Text("Dashboard ખૂલી રહ્યું છે...", color = Color.White, fontWeight = FontWeight.Medium)
                    }
                }
            }
        }
    }
}
